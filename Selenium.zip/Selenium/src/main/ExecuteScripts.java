package main;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import fuentes.Scripts.AddToCartScript;
import fuentes.Scripts.CompletePurchaseScript;
import fuentes.Scripts.ViewCartScript;

public class ExecuteScripts {
    public static void main(String[] args) {
        // Configura el sistema para usar el controlador de Chrome
        System.setProperty("webdriver.chrome.driver", "C:/Users/lusoto/Downloads/chromedriver/chromedriver.exe");

        // Inicializa el navegador Chrome
        WebDriver driver = new ChromeDriver();
        
        // Navega hasta la página principal
        driver.get("https://www.demoblaze.com/index.html");

        // Ejecuta el script para agregar un artículo al carrito
        AddToCartScript.addToCart(driver);

        // Ejecuta el script para visualizar el carrito de compras
        ViewCartScript.viewCart(driver);

        // Ejecuta el script para completar la compra
        CompletePurchaseScript.completePurchase(driver);
        
        // Cierra el navegador
        driver.quit();
    }
}
