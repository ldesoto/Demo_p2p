package fuentes.Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ViewCartScript {
    public static void viewCart(WebDriver driver) {
        // Configura el sistema para usar el controlador de Chrome
        //System.setProperty("webdriver.chrome.driver", "C:/Users/lusoto/Downloads/chromedriver/chromedriver.exe");

        // Inicializa el navegador Chrome
        //WebDriver driver = new ChromeDriver();
        
        // Navega hasta la página
        driver.get("https://www.demoblaze.com/index.html");

        // Haga clic en el enlace del carrito de compras
        WebElement cartLink = driver.findElement(By.id("cartur"));
        cartLink.click();
        
        // Espera un tiempo para asegurarse de que se cargue la página del carrito
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Obtiene el contenido del carrito de compras
        WebElement cartContent = driver.findElement(By.className("table-responsive"));
        
        // Imprime el contenido del carrito de compras
        System.out.println("Contenido del carrito:\n" + cartContent.getText());
        
        // Cierra el navegador
       // driver.quit();
    }
}
