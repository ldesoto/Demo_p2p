package fuentes.Scripts;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CompletePurchaseScript {
    public static void completePurchase(WebDriver driver) {
        // Configura el sistema para usar el controlador de Chrome
        //System.setProperty("webdriver.chrome.driver", "C:/Users/lusoto/Downloads/chromedriver/chromedriver.exe");

        // Inicializa el navegador Chrome
       // WebDriver driver = new ChromeDriver();

        // Navega hasta la página
        driver.get("https://www.demoblaze.com/index.html");

        // Haz clic en el enlace del carrito de compras
        WebElement cartLink = driver.findElement(By.id("cartur"));
        cartLink.click();

        // Haga clic en el botón "Place Order"
        WebElement placeOrderButton = driver.findElement(By.xpath("//button[contains(text(),'Place Order')]"));
        placeOrderButton.click();

        // Espera un tiempo para asegurarse de que se cargue el formulario
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Llena el formulario de información de envío
        WebElement nameField = driver.findElement(By.xpath("//input[@id='name']"));
        nameField.sendKeys("John Doe");

        WebElement countryField = driver.findElement(By.xpath("//input[@id='country']"));
        countryField.sendKeys("United States");

        WebElement cityField = driver.findElement(By.xpath("//input[@id='city']"));
        cityField.sendKeys("New York");

        WebElement cardField = driver.findElement(By.xpath("//input[@id='card']"));
        cardField.sendKeys("1234567890");

        WebElement monthField = driver.findElement(By.xpath("//input[@id='month']"));
        monthField.sendKeys("January");

        WebElement yearField = driver.findElement(By.xpath("//input[@id='year']"));
        yearField.sendKeys("2025");

        // Haga clic en el botón "Purchase"
        WebElement purchaseButton = driver.findElement(By.xpath("//button[contains(text(),'Purchase')]"));
        purchaseButton.click();

        // Espera un tiempo para asegurarse de que se procese la compra
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Obtiene el mensaje de confirmación de compra
        WebElement confirmationMessage = driver.findElement(By.xpath("//h2[contains(text(),'Thank you for your purchase!')]"));

        // Imprime el mensaje de confirmación
        System.out.println("Mensaje de confirmación: " + confirmationMessage.getText());

        // Cierra el navegador
        //driver.quit();
    }
}
