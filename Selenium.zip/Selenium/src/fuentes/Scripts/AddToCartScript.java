package fuentes.Scripts;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Assert;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class AddToCartScript {
    public static void addToCart(WebDriver driver) {
        // Configura el sistema para usar el controlador de Chrome
        // System.setProperty("webdriver.chrome.driver", "C:/Users/lusoto/Downloads/chromedriver/chromedriver.exe");

        // Inicializa el navegador Chrome
        // WebDriver driver = new ChromeDriver();

        // Navega hasta la página
        driver.get("https://www.demoblaze.com/index.html");

        // Espera hasta que se cargue la página
        WebDriverWait wait = new WebDriverWait(driver, 10);

        // Lee los productos desde el archivo Excel
        List<String> products = readProductsFromExcel("C:/Users/lusoto/OneDrive - Asociacion Popular de Ahorros y Prestamos/Documents/cell.xlsx");

        // Agrega los productos al carrito
        for (String product : products) {
            // Espera a que el artículo deseado esté disponible
            WebElement productLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(product)));

            // Haz clic en el artículo
            productLink.click();

            WebElement addToCartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Add to cart']")));
            // Haz clic en el botón "Add to cart"
            addToCartButton.click();

            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Captura el mensaje de la alerta
            String alertMessage = alert.getText();

            // Imprime el mensaje de la alerta
            System.out.println("Mensaje de la alerta: " + alertMessage);
            alert.accept();

            // Verifica que se muestre el mensaje de éxito
            Assert.assertEquals("Product added", alertMessage);

            // Regresa a la página principal
            driver.get("https://www.demoblaze.com/index.html");

            // Cierra el navegador
            // driver.quit();
        }
    }

    private static List<String> readProductsFromExcel(String filePath) {
        List<String> products = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                Cell cell = row.getCell(0);
                String product = cell.getStringCellValue();
                products.add(product);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return products;
    }
}
